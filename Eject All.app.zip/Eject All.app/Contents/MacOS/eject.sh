#!/usr/bin/env ruby
#eject-all shell script

# Dan Rosenstark 2015-11-12 15:28
# http://porkrind.org/missives/calling-applescript-from-ruby/
def osascript(script)
  system 'osascript', *script.split(/\n/).map { |line| ['-e', line] }.flatten
end

if __FILE__ == $0
  appleScript = "tell application \"Finder\" to eject (every disk whose ejectable is true and local volume is true and free space is not equal to 0)";
  osascript appleScript
  puts "I probably ejected all the disks."
end